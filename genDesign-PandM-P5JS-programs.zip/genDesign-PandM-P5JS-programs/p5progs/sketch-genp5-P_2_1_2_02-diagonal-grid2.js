// P_2_1_2_02.pde
// 
// Generative Gestaltung, ISBN: 978-3-87439-759-9
// First Edition, Hermann Schmidt, Mainz, 2009
// Hartmut Bohnacker, Benedikt Gross, Julia Laub, Claudius Lazzeroni
// Copyright 2009 Hartmut Bohnacker, Benedikt Gross, Julia Laub, Claudius Lazzeroni
//
// http://www.generative-gestaltung.de
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

/**
 * changing module color and positions in a grid
 * 	 
 * MOUSE
 * position x          : offset x
 * position y          : offset y
 * left click          : random position
 * 
 * KEYS
 * 1-3                 : different sets of colors
 * 0                   : default
 * arrow up/down       : background module size
 * arrow left/right    : foreground module size
 * s                   : save png
 * p                   : save pdf


import processing.pdf.*;
import java.util.Calendar;

boolean savePDF = false;
 */
var moduleColorBackground;
var moduleColorForeground;
var moduleAlphaBackground;
var moduleAlphaForeground;
var moduleRadiusBackground;
var moduleRadiusForeground;
var backColor;
var tileCount = 20;
var actRandomSeed = 0;

function setup(){
  createCanvas(600, 600);
  backColor = color(255);
  moduleColorBackground = color(0);
  moduleColorForeground = color(255);
  moduleAlphaBackground = 50;
  moduleAlphaForeground = 50;
  moduleRadiusBackground = 30;
  moduleRadiusForeground = 15;
}

function draw() {
  translate(width/tileCount/2, height/tileCount/2);
  colorMode(HSB, 360, 100, 100, 255);
  background(backColor);
  smooth();
  noStroke();
  randomSeed(actRandomSeed);

  for (var gridY=0; gridY<tileCount; gridY++) {
    for (var gridX=0; gridX<tileCount; gridX++) {
      var posX = width/tileCount * gridX;
      var posY = height/tileCount * gridY;

      var shiftX =  random(-1, 1) * mouseX/20;
      var shiftY =  random(-1, 1) * mouseY/20;
       
      //fill(150,10,20,25);
      fill(moduleColorBackground, moduleAlphaBackground);
      ellipse(posX+shiftX, posY+shiftY, moduleRadiusBackground, moduleRadiusBackground);
    }
  }

  for (var gridY=0; gridY<tileCount; gridY++) {
    for (var gridX=0; gridX<tileCount; gridX++) {

      var posX = width/tileCount * gridX;
      var posY = height/tileCount * gridY;
      //fill(150,10,20,25);
      fill(moduleColorForeground, moduleAlphaForeground);
      ellipse(posX, posY, moduleRadiusForeground, moduleRadiusForeground);
    }
  }
}

function mousePressed() {
  actRandomSeed = floor(random(100000));
}

function keyPressed(){
   //print("k=" + key);
   if (key == 1){
	  moduleColorBackground = color(150, 20, 51);
	  moduleColorForeground = color(200, 50, 77);
	  moduleAlphaBackground = 50;
      moduleAlphaForeground = 5;
  }
  if (key == 2){
      moduleColorForeground = color(323, 100, 77);
      moduleColorBackground = color(150, 50, 75);
  }

  if (key == 3){
      moduleAlphaBackground = 100;
      moduleAlphaForeground = 25;
  }
    if (key == 4){
      moduleAlphaBackground = 100;
      moduleAlphaForeground = 50;
  }
    if (key == 5){
      moduleAlphaBackground = 100;
      moduleAlphaForeground = 75;
  }

  if (key == 9){  
    moduleColorBackground = color(0);
    moduleColorForeground = color(360);
    moduleAlphaBackground = 100;
    moduleAlphaForeground = 100;
    moduleRadiusBackground = 20;
    moduleRadiusForeground = 10;
  }
  
  if (key == 0){
  moduleColorBackground = color(0);
  moduleColorForeground = color(255);
  moduleAlphaBackground = 50;
  moduleAlphaForeground = 50;
  moduleRadiusBackground = 30;
  moduleRadiusForeground = 15;
  }
  
  if (keyCode === UP_ARROW) moduleRadiusBackground += 2;
  if (keyCode === DOWN_ARROW) moduleRadiusBackground = max(moduleRadiusBackground-2, 10);
  if (keyCode === LEFT_ARROW) moduleRadiusForeground = max(moduleRadiusForeground-2, 5);
  if (keyCode === RIGHT_ARROW) moduleRadiusForeground += 2;

}
