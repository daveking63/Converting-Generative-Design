// P_3_1_2_01.pde
// 
// Generative Gestaltung, ISBN: 978-3-87439-759-9
// First Edition, Hermann Schmidt, Mainz, 2009
// Hartmut Bohnacker, Benedikt Gross, Julia Laub, Claudius Lazzeroni
// Copyright 2009 Hartmut Bohnacker, Benedikt Gross, Julia Laub, Claudius Lazzeroni
//
// http://www.generative-gestaltung.de
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

/**
 * typewriter. uses input (text) as blueprint for a visual composition.
 * 
 * MOUSE
 * drag                : move canvas
 * 
 * KEYS
 * a-z                 : text input (keyboard)
 * ,.!? and return     : curves
 * space               : small curve with random direction
 * del, backspace      : remove last letter
 * arrow up            : zoom canvas +
 * arrow down          : zoom canvas -
 * alt                 : new random layout
 * ctrl                : save png
*/

var font;
var textTyped = "";

var imgLoc, imageSpace, imageSpace2, imagePeriod, imageComma;
var imageQuestionmark, imageExclamationmark, imageReturn;

var centerX = 0, centerY = 0, offsetX = 0, offsetY = 0;
var zoom = 0.75;
var actRandomSeed = 6;

function preload(){
  imgLoc = "img-text1/";
  imageSpace = loadImage(imgLoc + "space.svg");
  imageSpace2 = loadImage(imgLoc + "space2.svg");
  imagePeriod = loadImage(imgLoc + "period.svg");
  imageComma = loadImage(imgLoc + "comma.svg"); 
  imageExclamationmark = loadImage(imgLoc + "exclamationmark.svg");
  imageQuestionmark = loadImage(imgLoc + "questionmark.svg");
  imageReturn = loadImage(imgLoc + "return.svg");
}

function setup() {
  createCanvas(displayWidth, displayHeight);
  //createCanvas(900, 900);
  // make window resizable
  // frame.setResizable(true); 
  
  // text to begin with
  textTyped += "Ich bin der Musikant mit Taschenrechner in der Hand!\n\n";
  textTyped += "Ich addiere\n";
  textTyped += "Und subtrahiere, \n\n";
  textTyped += "Kontrolliere\nUnd komponiere\nUnd wenn ich diese Taste drück,\nSpielt er ein kleines Musikstück?\n\n";
  
  textTyped += "Ich bin der Musikant mit Taschenrechner in der Hand!\n\n";
  textTyped += "Ich addiere\n";
  textTyped += "Und subtrahiere, \n\n";
  textTyped += "Kontrolliere\nUnd komponiere\nUnd wenn ich diese Taste drück,\nSpielt er ein kleines Musikstück?\n\n";
 
  //for(i=50;i<60;i++){
  //  print(textTyped.charAt(i));
  //}
  //print(textTyped.length);
  
  centerX = width/2;
  centerY = height/2;  

  font = "Arial";
  textFont(font,25);
  cursor(HAND);
}


function draw() {
  background(255);
  smooth();
  noStroke();
  textAlign(LEFT);

  if (mousePressed == true) {
    centerX = mouseX-offsetX;
    centerY = mouseY-offsetY;
  } 

  // always produce the same sequence of random numbers
  randomSeed(actRandomSeed);
  translate(centerX,centerY);
  scale(zoom);

  for (var i = 0; i < textTyped.length; i++) {
  	//print("tt lng=" + textTyped.length);
    var fontSize = 20;
    textFont(font,fontSize);
    var letter = textTyped.charAt(i);
    //print(letter);
    var letterWidth = textWidth(letter);
    // ------ letter rule table ------

    if (letter == ' ') {
      // 50% left, 50% right
      var dir = floor(random(0, 2));
	    if(dir == 0){
	        image(imageSpace, 0, 0);
	        translate(1.9, 0);
	        rotate(PI/4);
	    } else if(dir == 1){
	        image(imageSpace2, 0, 0);
	        translate(13, -5);
	        rotate(-PI/4);
	    }
    } else if (letter == ','){
	      image(imageComma, 0, 0);
	      translate(34, 15);
	      rotate(PI/4);
	} else if (letter == '.'){
	      image(imagePeriod, 0, 0);
	      translate(56, -54);
	      rotate(-PI/2);
	} else if (letter == '!'){  
	      image(imageExclamationmark, 0, 0);
	      translate(42, -17.4);
	      rotate(-PI/4);
 	} else if (letter == '?'){  
	      image(imageQuestionmark, 0, 0);
	      translate(42, -18);
	      rotate(-PI/4);
	} else if (letter == '\n'){ // return  
	      image(imageReturn, 0, 0);
	      translate(0, 10);
	      rotate(PI);
    } else {// all others
	      fill(0);
	      text(letter, 0, 0);
	      translate(letterWidth, 0);
    }
  }
    // blink cursor after text
    fill(0);
    if (frameCount/6 % 2 == 0) rect(0, 0, 15, 2);
}

function mousePressed(){
  offsetX = mouseX-centerX;
  offsetY = mouseY-centerY;
}

function keyPressed() {
	  if (keyCode == BACKSPACE){
	  	textTyped = textTyped.substring(0,max(0,textTyped.length-1));
	  } else if (keyCode == RETURN){
	    textTyped += "\n";
	  } else if (keyCode == ALT) {
	    actRandomSeed++;
	  } else if (keyCode == UP_ARROW) {
	    zoom += 0.05;
	  } else if (keyCode == DOWN_ARROW) {
	    zoom -= 0.05;  
	  }
}

function keyTyped() {
	  console.log(key)
	  textTyped += key;
	  letter = key;
}