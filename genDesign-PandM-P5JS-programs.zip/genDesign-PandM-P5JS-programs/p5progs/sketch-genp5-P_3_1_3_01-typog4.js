// P_3_1_3_01.pde
// 
// Generative Gestaltung, ISBN: 978-3-87439-759-9
// First Edition, Hermann Schmidt, Mainz, 2009
// Hartmut Bohnacker, Benedikt Gross, Julia Laub, Claudius Lazzeroni
// Copyright 2009 Hartmut Bohnacker, Benedikt Gross, Julia Laub, Claudius Lazzeroni
//
// http://www.generative-gestaltung.de
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

/**
 * analysing and sorting the letters of a text 
 * changing the letters alpha value in relation to frequency
 *
 * MOUSE
 * position x          : interpolate between normal text and sorted position
 *
 * KEYS
 * 1                   : toggle alpha mode
 * s                   : save png
 * p                   : save pdf

import processing.pdf.*;
import java.util.Calendar;
boolean savePDF = false;
 */
 
var font;
var joinedText;
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ,.;:!? ";
var counters = [];
var charSize;
var charColor = 0;
var posX, posY;
var drawAlpha = true;
var lines;

function preload(){
  lines = loadStrings("img-text1/faustkurz.txt");
}

function setup() {
  createCanvas(670, 800);
  joinedText = join(lines, " ");

  font = "Courier";
  fontSize = 10
  
  for(i=0;i<alphabet.length;i++){
    counters[i] = 0;
  }
  
  countCharacters();

}

function draw(){

  textFont(font);
  background(255);
  noStroke();
  smooth();

  posX = 20;
  posY = 40;

  // go through all characters in the text to draw them  
  for (var i = 0; i < joinedText.length; i++) {
    // again, find the index of the current letter in the alphabet
    var s = str(joinedText.charAt(i)).toUpperCase();
    var uppercaseChar = s.charAt(0);
    var index = alphabet.indexOf(uppercaseChar);
    if (index < 0) continue;

    if (drawAlpha) fill(87, 35, 129, counters[index]*3);
    else fill(87, 35, 129);
    textSize(18);

    var sortY = index*20+40;
    var m = map(mouseX, 50,width-50, 0,1);
    m = constrain(m, 0, 1);
    var interY = lerp(posY, sortY, m);

    text(joinedText.charAt(i), posX, interY);

    posX += textWidth(joinedText.charAt(i));
    if (posX >= width-200 && uppercaseChar == ' ') {
      posY += 30;
      posX = 20;
    }
  }
}

function countCharacters(){
  for (var i = 0; i < joinedText.length; i++) {
    // get one char from the text, convert it to a string and turn it to uppercase
    var c = joinedText.charAt(i);
    var s = str(c);
    s = s.toUpperCase();
    // convert it back to a char
    var uppercaseChar = s.charAt(0);
    // get the position of this char inside the alphabet string
    var index = alphabet.indexOf(uppercaseChar);
    // increase the respective counter
    if (index >= 0){
       counters[index] += 1;
    }
  }
}

function keyPressed(){
  if (key == '1') drawAlpha = !drawAlpha;
}
