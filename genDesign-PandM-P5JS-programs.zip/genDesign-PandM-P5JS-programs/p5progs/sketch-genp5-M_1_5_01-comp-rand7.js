// M_1_5_01.pde
// 
// Generative Gestaltung, ISBN: 978-3-87439-759-9
// First Edition, Hermann Schmidt, Mainz, 2009
// Hartmut Bohnacker, Benedikt Gross, Julia Laub, Claudius Lazzeroni
// Copyright 2009 Hartmut Bohnacker, Benedikt Gross, Julia Laub, Claudius Lazzeroni
//
// http://www.generative-gestaltung.de
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

/**
 * how to transform noise values into directions (angles) and brightness levels
 * 
 * MOUSE
 * position x/y        : specify noise input range
 * 
 * KEYS
 * d                   : toogle display brightness circles on/off
 * arrow up            : noise falloff +
 * arrow down          : noise falloff -
 * arrow left          : noise octaves -
 * arrow right         : noise octaves +
 * space               : new noise seed
 * s                   : save png
 * p                   : save pdf
import processing.pdf.*;
import java.util.Calendar;

boolean savePDF = false;
 */
var octaves = 4;
var falloff = 0.5;

var arcColor;

var tileSize = 40;
var gridResolutionX, gridResolutionY;
var debugMode = true;
var arrow;

function preload(){
	arrow = loadImage("img-arrow/arrow.svg");
}

function setup() {
  createCanvas(800,800); 
  cursor(CROSS);
  gridResolutionX = round(width/tileSize);
  gridResolutionY = round(height/tileSize);
  arcColor = color(0,130,164,100)
  smooth();
}

function draw() {
  background(255);

  noiseDetail(octaves,falloff);
  var noiseXRange = mouseX/100.0;
  var noiseYRange = mouseY/100.0;

  for (var gY=0; gY<= gridResolutionY; gY++) {  
    for (var gX=0; gX<= gridResolutionX; gX++) {
      var posX = tileSize*gX;
      var posY = tileSize*gY;

      // get noise value
      var noiseX = map(gX, 0,gridResolutionX, 0,noiseXRange);
      var noiseY = map(gY, 0,gridResolutionY, 0,noiseYRange);
      var noiseValue = noise(noiseX,noiseY);
      var angle = noiseValue*TWO_PI;

      push();
      translate(posX,posY);

      // debug heatmap
      if (debugMode) {
        noStroke();
        ellipseMode(CENTER);
        fill(noiseValue*255);
        ellipse(0,0,tileSize*0.25,tileSize*0.25);
      }

      // arc
      noFill();
      strokeCap(SQUARE);
      strokeWeight(1);
      stroke(arcColor);
      arc(0,0,tileSize*0.75,tileSize*0.75,0,angle);

      // arrow
      stroke(0);
      strokeWeight(0.75);
      rotate(angle);
      image(arrow,0,0,tileSize*0.75,tileSize*0.75);
      pop();
    }
  }

 // print("octaves: "+octaves+" falloff: "+falloff+" noiseXRange: 0-"+noiseXRange+" noiseYRange: 0-"+noiseYRange); 
}

function keyPressed() {  

  if (key == ' ') noiseSeed(float(random(100000)));
  if (keyCode == UP_ARROW) falloff += 0.05;
  if (keyCode == DOWN_ARROW) falloff -= 0.05;
  if (falloff > 1.0) falloff = 1.0;
  if (falloff < 0.0) falloff = 0.0;

  if (keyCode == LEFT_ARROW) octaves--;
  if (keyCode == RIGHT_ARROW) octaves++;
  if (octaves < 0) octaves = 0;
}