// P_4_3_3_01.pde
// 
// Generative Gestaltung, ISBN: 978-3-87439-759-9
// First Edition, Hermann Schmidt, Mainz, 2009
// Hartmut Bohnacker, Benedikt Gross, Julia Laub, Claudius Lazzeroni
// Copyright 2009 Hartmut Bohnacker, Benedikt Gross, Julia Laub, Claudius Lazzeroni
//
// http://www.generative-gestaltung.de
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

/**
 * generating a drawing by analysing live video
 * 
 * MOUSE
 * position x          : drawing speed
 * position y          : diffusion
 *
 * KEYS
 * arrow up            : number of curve points +
 * arrow down          : number of curve points -
 * q                   : stop drawing
 * w                   : continue drawing
 * s                   : save png
 * r                   : start record pdf
 * e                   : end record pdf
 *


import processing.video.*;
import processing.pdf.*;
import java.util.Calendar;

boolean savePDF = false;
 */

var video;
var x, y;
var curvePointX = 0; 
var curvePointY = 0;
var pointCount = 1;
var diffusion = 50;

function setup() {
  createCanvas(640, 480);
  background(255);
  x = width/2;
  y = height/2;
  pixelDensity(1);
  video = createCapture(VIDEO);
  video.size(width, height, 30);
  print(width + " " + height + " " + x + " " + y);
  print(video.width + " " + video.height);
}

function draw() {
  colorMode(HSB, 360, 100, 100);
  smooth();
  noFill();

  for (var j=0; j<=mouseX/50; j++) {
  //for (var j=0; j<=5; j++) {
    video.loadPixels();
    var pVx = video.width-1-x
    var pVy = y*video.width
    //var pIdx = ((video.width-1-x) + y*video.width);
    var pIdx = (pVx + pVy) * 4;
    print(j + " " + pVx + " " + pVy + " " + pIdx);
    var h = video.pixels[pIdx];
    var s = video.pixels[pIdx + 1];
    var b = video.pixels[pIdx + 2];
    //var hueValue = hue(c);
    strokeWeight(h/50);
    var c = color(h, s, b, 255);
    print (h + " " + s + " " + b);
    print (c);
    stroke(c);
    
    diffusion = map(mouseY, 0,height, 5,100);

    beginShape();
	    curveVertex(x, y);
	    curveVertex(x, y);
	    for (var i = 0; i < pointCount; i++) {
	      var rx = floor(random(-diffusion, diffusion));
	      curvePointX = constrain(x+rx, 0, width-1);
	      var ry = floor(random(-diffusion, diffusion));
	      curvePointY = constrain(y+ry, 0, height-1);
	      curveVertex(curvePointX, curvePointY);
	    }
	    curveVertex(curvePointX, curvePointY);
    endShape();
    
    x = curvePointX;
    y = curvePointY;
  }
}


function keyPressed(){
  if (key == BACKSPACE) background(360);
  if (key == 'q' || key == 'S') noLoop();
  if (key == 'w' || key == 'W') loop();
  if (keyCode == UP_ARROW) pointCount = min(pointCount+1, 30);
  if (keyCode == DOWN_ARROW) pointCount = max(pointCount-1, 1); 
}
