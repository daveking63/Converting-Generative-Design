// M_4_1_01.pde
// Node.pde
// 
// Generative Gestaltung, ISBN: 978-3-87439-759-9
// First Edition, Hermann Schmidt, Mainz, 2009
// Hartmut Bohnacker, Benedikt Gross, Julia Laub, Claudius Lazzeroni
// Copyright 2009 Hartmut Bohnacker, Benedikt Gross, Julia Laub, Claudius Lazzeroni
//
// http://www.generative-gestaltung.de
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

/**
 * some moving nodes
 *
 * KEYS
 * r             : re-initialize velocity vectors of the nodes
 * s             : save png



import java.util.Calendar;
 */
var nodeCount = 20;

// myNodes array 
//Node[] myNodes = new Node[nodeCount];
var myNodes = [];

function setup() {
  createCanvas(600,600); 
  colorMode(RGB, 255, 255, 255, 100);
  smooth();
  background(255); 
  noStroke();
  fill(0);

  // setup myNodes
  for (var i = 0; i < nodeCount; i++) {
    myNodes[i] = new Node(random(width), random(height), 10);
  print(myNodes.length);
    //myNodes[i].velocity.x = random(-3, 3);
    //myNodes[i].velocity.y = random(-3, 3);
    //myNodes[i].damping = 0.01;
  }
}

function draw() {
	fill(255, 5);
	rect(0, 0, width, height);
	stroke(150);
	//fill(0, 100);
	for (var i = 0; i < myNodes.length; i++) {
		myNodes[i].update();
		myNodes[i].display();
	}
	//print('got here 2');
	//print(myNodes[0].x + " " + myNodes[0].y + " " + myNodes[19].x  + " " + myNodes[19].y);
}

function Node(tempX, tempY, tempDiameter) {
	//print('got here1');
    var minX=5, minY=5, maxX=width-5, maxY=height-5;
    // damping of the velocity (0 = no damping, 1 = full damping)
    this.damping = 0.1;
	this.x = tempX;
	this.y = tempY;
	this.diameter = tempDiameter;
	this.velocity = createVector(this.x, this.y);
	this.velocity.x = random(-3, 3);
	this.velocity.y = random(-3, 3);
    //print(this.x + " " + this.y + " " + this.velocity.x + " " + this.velocity.y);
			
	this.update = function() {
		//print('got here update');
	    this.x += this.velocity.x;
	    this.y += this.velocity.y;

	    if (this.x < minX) {
	      this.x = minX - (this.x - minX);
	      this.velocity.x = -this.velocity.x;
	    }
	    if (this.x > maxX) {
	      this.x = maxX - (this.x - maxX);
	      this.velocity.x = -this.velocity.x;
	    }

	    if (this.y < minY) {
	      this.y = minY - (this.y - minY);
	      this.velocity.y = -this.velocity.y;
	    }
	    if (this.y > maxY) {
	      this.y = maxY - (this.y - maxY);
	      this.velocity.y = -this.velocity.y;
	    }
	    this.velocity.x *= (1-this.damping);
	    this.velocity.y *= (1-this.damping);
	  }

	this.display = function() {
		print('got here display');
		print(this.x + "  " + this.y);
		fill(0, 100);
		ellipse(this.x, this.y, this.diameter, this.diameter);
	}
}

/*
function keyPressed(){
  if(key=='r' || key=='R') {
    for (var i = 0; i < nodeCount; i++) {
      myNodes[i].velocity.x = random(-5, 5);
      myNodes[i].velocity.y = random(-5, 5);
    }
  }
}
*/