// P_4_2_1_02.pde
// 
// Generative Gestaltung, ISBN: 978-3-87439-759-9
// First Edition, Hermann Schmidt, Mainz, 2009
// Hartmut Bohnacker, Benedikt Gross, Julia Laub, Claudius Lazzeroni
// Copyright 2009 Hartmut Bohnacker, Benedikt Gross, Julia Laub, Claudius Lazzeroni
//
// http://www.generative-gestaltung.de
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

/**
 * radial collage generator. example footage can be found in "_4_2_1_footage".
 * if you use your own footage, make sure to rename the files or adjust the prefixes: 
 * see the parameters of generateCollageItems()
 * 
 * KEYS
 * 1-3                  : create a new collage (layer specific)
 * s                    : save png
 */

var images = [];
var imageNames = [];
var imageCnts = [];
var imagePath;
var imagesTotCnt = 0;

var layer1Items = [];
var layer2Items = [];
var layer3Items = [];
var layerCount = 3;

var items = [];

function preload() {
  // hard coded imagePath, imageCnts & imageName "prefix", and extension
  imagePath = "img-collage/";
  imageCnts[0] = 11;
  imageCnts[1] = 5;
  imageCnts[2] = 22;
  for (var i = 0; i < layerCount; i++) {
	  for (var j = 0; j < imageCnts[i] ; j++) {
	  	  imageNames[imagesTotCnt] = "layer" + nf(i + 1, 1) + "_" + nf(j + 1, 2);
	  	  images[imagesTotCnt] = loadImage(imagePath + imageNames[imagesTotCnt] + ".png");
	  	  imagesTotCnt++;
	  }
  }
}

function setup() {
  createCanvas(1024, 768);
  imageMode(CENTER);
  background(255);

  layer1Items = generateCollageItems("layer1", 100, 0,height/2, TWO_PI,height, 0.1,0.5, 0,0);
  layer2Items = generateCollageItems("layer2", 150, 0,height/2, TWO_PI,height, 0.1,0.3, -PI/6,PI/6);
  layer3Items = generateCollageItems("layer3", 110, 0,height/2, TWO_PI,height, 0.1,0.2, 0,0);


  // draw collage
  drawCollageItems(layer1Items);
  drawCollageItems(layer2Items);
  drawCollageItems(layer3Items); 

}

function draw() {
  // keep the programm running
}
// ------interactions and generation of the collage ------
function keyTyped() {
  if (key == 's' || key == 'S') save("P_4_2_1_02.png");

  if (key == '1') layer1Items = generateCollageItems("layer1", int(random(50,200)), 0,height/2,PI*5,height, 0.1,0.5, 0,0);
  if (key == '2') layer2Items = generateCollageItems("layer2", int(random(25,300)), 0,height*0.15,PI*5,150, 0.1,random(0.3,0.8), -PI/6,PI/6);
  if (key == '3') layer3Items = generateCollageItems("layer3", int(random(50,300)), 0,height*0.66,PI*5,height*0.66, 0.1,random(0.2,0.5), -0.05,0.05);


  // draw collage
  background(255);
  drawCollageItems(layer1Items);
  drawCollageItems(layer2Items);
  drawCollageItems(layer3Items);
}

// ------ collage object ------
function collageItem(tempA, tempL, tempScale, tempRotate, tempIndex) {
  this.a = tempA
  this.l = tempL;
  this.scaling = tempScale;
  this.rotation = tempRotate;
  this.indexToImage = tempIndex;
}

// ------ collage items helper functions ------
function generateCollageItems(thePrefix, theCount, theAngle, theLength, theRangeA, theRangeL, theScaleStart, theScaleEnd, theRotationStart, theRotationEnd)  {
	
  // collect all images with the specified prefix "thePrefix"
  var indexes = [];
  for (var i = 0 ; i < imageNames.length; i++) {
  	  var iFind = match(imageNames[i], thePrefix); // find images associated with a given layer
  	  if (iFind != null){
		indexes = append(indexes, i);
  	  }	
  }
  for (var i = 0 ; i < theCount; i++) {
    tmpA = theAngle + random(-theRangeA/2,theRangeA/2);;
    tmpL = theLength + random(-theRangeL/2,theRangeL/2);
    tmpScale = random(theScaleStart,theScaleEnd);
    tmpRotate = tmpA + HALF_PI + random(theRotationStart,theRotationEnd);
    tmpIndx = indexes[i % indexes.length] // cycles around the images in a given layer
    items[i] = new collageItem(tmpA, tmpL, tmpScale, tmpRotate, tmpIndx);
  }
  return items;
}

function drawCollageItems(theItems) {
  for (var i = 0 ; i < theItems.length; i++) {
    push();
        var newX  = width/2 + cos(theItems[i].a) * theItems[i].l;
        var newY  = height/2 + sin(theItems[i].a) * theItems[i].l; 
        translate(newX, newY);
	    rotate(theItems[i].rotation);
	    scale(theItems[i].scaling);
	    image(images[theItems[i].indexToImage], 0,0);
    pop();
  }
}