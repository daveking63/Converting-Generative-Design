// M_1_3_02.pde
// 
// Generative Gestaltung, ISBN: 978-3-87439-759-9
// First Edition, Hermann Schmidt, Mainz, 2009
// Hartmut Bohnacker, Benedikt Gross, Julia Laub, Claudius Lazzeroni
// Copyright 2009 Hartmut Bohnacker, Benedikt Gross, Julia Laub, Claudius Lazzeroni
//
// http://www.generative-gestaltung.de
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

/**
 * creates a texture based on random values
 * 
 * MOUSE
 * click               : new noise line
 * 
 * KEYS
 * s                   : save png

import java.util.Calendar;
 */
var actRandomSeed = 0;
//var greyColors = [0, 47, 112, 119, 105, 128, 169, 192, 211, 220, 255];

var greyColors = 
	[
	0, 3, 5, 8, 10, 13, 15,
	18, 20, 23, 26, 28, 31,
	33, 36, 38, 41, 43, 46,
	48, 51, 52, 54, 58, 61,
	64, 66, 69, 71, 74, 77, 79,
	82, 85, 87, 89, 92, 94,
	97, 99, 102, 105, 107, 110,
	112, 115, 117, 120, 122, 125,
	128, 130, 133, 135, 138, 140, 143,
	145, 148, 150, 153, 156, 158,
	161, 163, 166, 168, 169,
	176, 179, 181, 184, 186, 189,
	192, 194, 196, 199, 201, 204, 205, 207,
	209, 211, 212, 214, 217, 219, 220, 222,
	224, 227, 229, 232, 235, 237,
	240, 242, 245, 247, 250, 255
	];

function setup() {
  createCanvas(512,512);
  //createCanvas(200,200);
}

function draw() {
  background(0);
  randomSeed(actRandomSeed);
  loadPixels();
  var d = pixelDensity();
  var wholeImage = 4 * (width * d) * (height * d);
  //for (var x = 0; x < width; x++) {
  //  for (var y = 0; y < height; y++) {
  for (var i = 0; i < wholeImage; i+=4){
  	  var cPtr = floor(random(0, 101));
  	  var c = greyColors[cPtr];
  	  //print(cPtr + " " + c);
      //var r = round(.299 * random(0,255));
      //var g = round(.587 * random(0,255));
      //var b = round(.114 * random(0,255));

      pixels[i] = c;
      pixels[i+1] = c;
      pixels[i+2] = c;
    }
  updatePixels();
}

function mouseReleased() {
  actRandomSeed = floor(random(100000));
}
