// M_1_3_03.pde
// 
// Generative Gestaltung, ISBN: 978-3-87439-759-9
// First Edition, Hermann Schmidt, Mainz, 2009
// Hartmut Bohnacker, Benedikt Gross, Julia Laub, Claudius Lazzeroni
// Copyright 2009 Hartmut Bohnacker, Benedikt Gross, Julia Laub, Claudius Lazzeroni
//
// http://www.generative-gestaltung.de
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

/**
 * creates a texture based on noise values
 * 
 * MOUSE
 * position x/y        : specify noise input range
 * 
 * KEYS
 * 1-2                 : set noise mode
 * arrow up            : noise falloff +
 * arrow down          : noise falloff -
 * arrow left          : noise octaves -
 * arrow right         : noise octaves +
 * s                   : save png
 
import java.util.Calendar;
*/

var octaves = 4;
var falloff = 0.5;
var noiseMode = 1;
var greyColors = 
	[
	0, 3, 5, 8, 10, 13, 15,
	18, 20, 23, 26, 28, 31,
	33, 36, 38, 41, 43, 46,
	48, 51, 52, 54, 58, 61,
	64, 66, 69, 71, 74, 77, 79,
	82, 85, 87, 89, 92, 94,
	97, 99, 102, 105, 107, 110,
	112, 115, 117, 120, 122, 125,
	128, 130, 133, 135, 138, 140, 143,
	145, 148, 150, 153, 156, 158,
	161, 163, 166, 168, 169,
	176, 179, 181, 184, 186, 189,
	192, 194, 196, 199, 201, 204, 205, 207,
	209, 211, 212, 214, 217, 219, 220, 222,
	224, 227, 229, 232, 235, 237,
	240, 242, 245, 247, 250, 255
	];


function setup() {
  createCanvas(512,512);
  smooth();
  cursor(CROSS);
}

function draw() {
  background(0);

  noiseDetail(octaves,falloff);
  
  var noiseXRange = mouseX/10;
  var noiseYRange = mouseY/10;

  loadPixels();
  for (var x = 0; x < width; x++) {
    for (var y = 0; y < height; y++) {
      var noiseX = map(x, 0,width, 0,noiseXRange);
      var noiseY = map(y, 0,height, 0,noiseYRange);

      var noiseValue = 0;
      if (noiseMode == 1) { 
        noiseValue = noise(noiseX,noiseY) * 255;
      } 
      else if (noiseMode == 2) {
        var n = noise(noiseX,noiseY) * 24;
        noiseValue = (n- floor(n)) * 255;
      }

      var cPtr = floor(map(noiseValue, 0,255, 0,101));
  	  var c = greyColors[cPtr];
  	  //print(cPtr + " " + c);
      var r = c;
      var g = c;
      var b = c;
      var i = (x + y * width) * 4;
      pixels[i] = r;
      pixels[i+1] = g;
      pixels[i+2] = b;
      pixels[i+3] = 255;
    }
  }
  updatePixels();
}

function keyReleased() {  
  if (key == ' ') noiseSeed(floor(random(100000)));
  if (key == '1') noiseMode = 1;
  if (key == '2') noiseMode = 2;
  if (keyCode == UP_ARROW) falloff += 0.05;
  if (keyCode == DOWN_ARROW) falloff -= 0.05;
  if (falloff > 1.0) falloff = 1.0;
  if (falloff < 0.0) falloff = 0.0;

  if (keyCode == LEFT_ARROW) octaves--;
  if (keyCode == RIGHT_ARROW) octaves++;
  if (octaves < 0) octaves = 0;
}

/*
Shiffman Nature of Code provides alternative method:
loadPixels();
var xoff = 0.0;
for (var x = 0; x < width; x++){
	var yoff = 0.0;
	for (var y = 0; y < height; y++){
		var bright = map(noise(xoff,yoff), 0, 1, 0, 255);
		pixels[x + y*width] = color(bright);
		yoff += 0.01;
	}
	xoff += 0.01;
}
updatePixels();
*/