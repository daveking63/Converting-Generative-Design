// P_2_2_2_01.pde
// 
// Generative Gestaltung, ISBN: 978-3-87439-759-9
// First Edition, Hermann Schmidt, Mainz, 2009
// Hartmut Bohnacker, Benedikt Gross, Julia Laub, Claudius Lazzeroni
// Copyright 2009 Hartmut Bohnacker, Benedikt Gross, Julia Laub, Claudius Lazzeroni
//
// http://www.generative-gestaltung.de
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

/**
 * draw the path of an intelligent agent
 * 
 * MOUSE
 * position x          : composition speed of the picture
 *
 * KEYS
 * Delete/Backspace    : clear display
 * s                   : save png

import processing.pdf.*;
import java.util.Calendar;


 */
var recordPDF = false;

var NORTH = 0;
var EAST = 1;
var SOUTH = 2;
var WEST = 3;

var posX, posY;
var posXcross, posYcross;

var direction = SOUTH;
var angleCount = 4;    //// 1 - ...
var angle;
var stepSize = 100;
var minLength = 90;

function setup(){
  createCanvas(600, 600);
  colorMode(HSB, 360, 100, 100, 100);
  smooth();
  background(360);
  angle = getRandomAngle(direction)
  posX = floor((random(0, width)));
  posY = 5;
  posXcross = posX;
  posYcross = posY;
  stopVal = true;
  frameRate(3);
}


function draw(){
  if (stopVal){
  var fauxMouseX = random(0,20);
  //background(255);
  //for (var i=0; i<=mouseX; i++) {
  for (var i=0; i<=fauxMouseX; i++) {
  	// ------ draw dot at current position ------
      strokeWeight(1);
      stroke(180);
      point(posX, posY);
    // ------ make step ------
    posX += cos(radians(angle)) * stepSize;
    posY += sin(radians(angle)) * stepSize;
    print(cos(radians(angle)) + " " + round(posX) + " " + sin(radians(angle)) + " " + round(posY));

    // ------ check if agent is near one of the display borders ------
    var reachedBorder = false;

    if (posY <= 5) {
      direction = SOUTH;
      reachedBorder = true;
    } 
    else if (posX >= width-5) {
      direction = WEST;
      reachedBorder = true;
    }
    else if (posY >= height-5) {
      direction = NORTH;
      reachedBorder = true;
    }
    else if (posX <= 5) {
      direction = EAST;
      reachedBorder = true;
    }
    //print(direction + " " + reachedBorder);
    // ------ if agent is crossing his path or border was reached ------
    var px = floor(posX);
    var py = floor(posY);
    var ing = 0
    if (get(px, py) != color(360) || reachedBorder) {
      ing = 1
      //print(get(px,py) + "--" + reachedBorder);
      angle = getRandomAngle(direction);
      var distance = dist(posX, posY, posXcross, posYcross);
      print(round(angle) + "--" + round(distance));
      print(round(posX) + "--" + round(posY) + "--" + round(posXcross) + "--" + round(posYcross));
      if (distance >= minLength) {
      	ing = 3;
        strokeWeight(3);
        stroke(0);
        line(posX, posY, posXcross, posYcross);
      }
      posXcross = posX;
      posYcross = posY;
      print(ing);
    }
  }
}
}

function getRandomAngle(theDirection) {
  var a = floor(random(-angleCount, angleCount) + 0.5) 
  a = a * 90.0/angleCount;

  if (theDirection == NORTH) return (a - 90);
  if (theDirection == EAST) return (a);
  if (theDirection == SOUTH) return (a + 90);
  if (theDirection == WEST) return (a + 180);
  return 0;
}

function keyPressed(){
	if (key == 1) stopVal = false;
	if (key=='s' || key=='S') save("P_1_0_01.png");
}
