// P_3_1_2_02.pde
// 
// Generative Gestaltung, ISBN: 978-3-87439-759-9
// First Edition, Hermann Schmidt, Mainz, 2009
// Hartmut Bohnacker, Benedikt Gross, Julia Laub, Claudius Lazzeroni
// Copyright 2009 Hartmut Bohnacker, Benedikt Gross, Julia Laub, Claudius Lazzeroni
//
// http://www.generative-gestaltung.de
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

/**
 * typewriter. uses input (text) as blueprvar for a visual composition.
 * 
 * MOUSE
 * click + drag        : move canvas
 * 
 * KEYS
 * a-z                 : text input (keyboard)
 * space               : random straight / small curve
 * ,.!?                : curves
 * :+-xz               : icons
 * o                   : station with the last 7 typed letters as name
 * a u                 : stop
 * del, backspace      : remove last letter
 * arrow up            : zoom canvas +
 * arrow down          : zoom canvas -
 * ctrl                : save png
 */


var font;
var textTyped = "";

var imageSpace, imageSpace2, imagePeriod, imageComma, imageExclamationmark;
var imageQuestionmark, imageReturn, icon1, icon2, icon3, icon4, icon5;

var centerX = 0, centerY = 0, offsetX = 0, offsetY = 0;
var zoom = 0.75;

var palette = [];
var actColorIndex = 0;

function preload(){
  imgLoc = "img-text1/";
  imageSpace = loadImage(imgLoc + "space.svg");
  imageSpace2 = loadImage(imgLoc + "space2.svg");
  imagePeriod = loadImage(imgLoc + "period.svg");
  imageComma = loadImage(imgLoc + "comma.svg"); 
  imageExclamationmark = loadImage(imgLoc + "exclamationmark.svg");
  imageQuestionmark = loadImage(imgLoc + "questionmark.svg");
  imageReturn = loadImage(imgLoc + "return.svg");
  icon1 = loadImage(imgLoc + "icon1.svg");
  icon2 = loadImage(imgLoc + "icon2.svg");
  icon3 = loadImage(imgLoc + "icon3.svg");
  icon4 = loadImage(imgLoc + "icon4.svg");
  icon5 = loadImage(imgLoc + "icon5.svg");
}

function setup() {
  //createCanvas(800, 600);
  createCanvas(displayWidth, displayHeight);

  centerX = width/2;
  centerY = height/2;  

  font = "Arial";
  textFont(font,10);

  textTyped = "Was hier folgt ist Text! So asnt, und mag. Ich mag Text sehr.";
  
  palette[0] = color(253, 195, 0)
  palette[1] = color(0)
  palette[2] = color(0, 158, 224)
  palette[3] = color(99, 33, 129), 
  palette[4] = color(121, 156, 19)
  palette[5] = color(226, 0, 26)
  palette[6] = color(224, 134, 178)

  cursor(HAND);
}

function draw() {
  background(255);
  smooth();
  noStroke();
  textAlign(LEFT);

  if (mousePressed == true) {
    centerX = mouseX-offsetX;
    centerY = mouseY-offsetY;
  } 

  translate(centerX,centerY);
  scale(zoom);
  push();

  randomSeed(0);

  actColorIndex = 0;
  fill(palette[actColorIndex]);
  rect(0, -25, 10, 35);

  for (var i = 0; i < textTyped.length; i++) {
    var fontSize = 25;
    textFont(font,fontSize);
    var letter = textTyped.charAt(i);
    var letterWidth = textWidth(letter);

    // ------ letter rule table ------
    if (letter == ' ') {
      // 60% noturn, 20% left, 20% right
      var dir = floor(random(0, 5));
	    if(dir == 0){
	        image(imageSpace, 0, 0);
	        translate(1.9, 0);
	        rotate(PI/4);
	    } else if(dir == 1){
	        image(imageSpace2, 0, 0);
	        translate(13, -5);
	        rotate(-PI/4);
	    }
    } else if (letter == ','){
	      image(imageComma, 0, 0);
	      translate(34, 15);
	      rotate(PI/4);
    } else if (letter == '.'){
	      image(imagePeriod, 0, 0);
	      translate(56, -54);
	      rotate(-PI/2);
    } else if (letter == '!'){  
	      image(imageExclamationmark, 0, 0);
	      translate(42, -17.4);
	      rotate(-PI/4);
    } else if (letter == '?'){  
	      image(imageQuestionmark, 0, 0);
	      translate(42, -18);
	      rotate(-PI/4);
    } else if (letter == '\n'){ // return  
      // start a new line at a random position near the center
      	  rect(0,-25,10,35);
          pop();
          push();
          translate(random(-300,300), random(-300,300));
          rotate(floor(random(8))*PI/4);
          // choose nest color from the palette
          actColorIndex = (actColorIndex+1) % palette.length;
          fill(palette[actColorIndex]);
          rect( 0,-25,10,35);
    } else if (letter == 'o'){
      	  rect(0,0-15,letterWidth+1,15);
          push();
          fill(0);
          var station = textTyped.substring(i-10,i-1);
          station = station.toLowerCase();
          //station = station.replaceAll(" ", "");
          var stationArr = station.split(" ");
          station = join(stationArr,"");
          station = station.substring(0,1).toUpperCase() + station.substring(1,station.length-1);
          text(station,-10,40); 
          ellipse(-5,-7,33,33);
          fill(255);
          ellipse(-5,-7,25,25);
          pop();
          translate(letterWidth, 0);
    } else if (letter == 'a'){
          // Station small left
          rect(0,0-15,letterWidth+1,25);
          rect(0,0-15,letterWidth+1,15);
          translate(letterWidth, 0);
    } else if (letter == 'u'){
          // Station small right
          rect(0,0-25,letterWidth+1,25);
          rect(0,0-15,letterWidth+1,15);
          translate(letterWidth, 0);
    } else if (letter == ':'){
          // icon
          image(icon1,0,-60,30,30);
    } else if (letter == '+'){
          image(icon2,0,-60,35,30);
    } else if (letter == ':'){
    	  // icon
          image(icon3,0,-60,30,30);
    } else if (letter == 'x'){
          // icon
          image(icon4,0,-60,30,30);
    } else if (letter == 'z'){
         // icon
          image(icon5,0,-60,30,30);
    } else { // all others
         //text(letter, 0, 0);
          rect(0,0-15,letterWidth+1,15);
          translate(letterWidth, 0);
          //  rotate(-0.05);
    }

  }

  // blink cursor after text
  fill(200,30,40);
  if (frameCount/6 % 2 == 0) rect(0, 0, 15, 2);

  pop();
}

function mousePressed(){
  offsetX = mouseX-centerX;
  offsetY = mouseY-centerY;
}

function keyPressed() {
	  if (keyCode == BACKSPACE){
	  	textTyped = textTyped.substring(0,max(0,textTyped.length-1));
	  } else if (keyCode == RETURN){
	    textTyped += "\n";
	  } else if (keyCode == ALT) {
	    actRandomSeed++;
	  } else if (keyCode == UP_ARROW) {
	    zoom += 0.05;
	  } else if (keyCode == DOWN_ARROW) {
	    zoom -= 0.05;  
	  }
}

function keyTyped() {
	  console.log(key)
	  textTyped += key;
	  letter = key;
}