// P_2_3_6_02.pde
// 
// Generative Gestaltung, ISBN: 978-3-87439-759-9
// First Edition, Hermann Schmidt, Mainz, 2009
// Hartmut Bohnacker, Benedikt Gross, Julia Laub, Claudius Lazzeroni
// Copyright 2009 Hartmut Bohnacker, Benedikt Gross, Julia Laub, Claudius Lazzeroni
//
// http://www.generative-gestaltung.de
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

/**
 * draw tool. draws a specific module according to 
 * its east, south, west and north neighbours.
 * with switchable tileset 
 * 
 * MOUSE
 * drag left           : draw new module
 * drag right          : delete a module
 * 
 * KEYS
 * 1-8                 : switch tileset
 * y,x,c,v,b           : switch colors
 * del, backspace      : clear screen
 * r                   : random tiles
 * s                   : save png
 * p                   : save pdf
 * g                   : toogle. show grid
 * d                   : toogle. show module values
 
import processing.pdf.*;
import java.util.Calendar;
boolean savePDF = false;
*/

var tileSize = 30;
var gridResolutionX, gridResolutionY;
var drawGrid = true;
var tiles = [];
var tileColors = [];
var randomMode = false;
var font;
var fontSize;

var imgsA = [];
var imgsB = [];
var imgsC = [];
var imgsD = [];
var imgsE = [];
var imgsF = [];
var imgsG = [];
var imgsH = [];
var imgs  = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];
var activeImgSet = 'A';
var lngth = 16;

function preload(){
	var imgLoc = "imgs-module2/";
    for (var i=0; i<lngth; i++) { 
	    imgsA[i] = loadImage(imgLoc + "A_"+nf(i,2)+".svg");
	    imgsB[i] = loadImage(imgLoc + "B_"+nf(i,2)+".svg");
	    imgsC[i] = loadImage(imgLoc + "C_"+nf(i,2)+".svg");
	    imgsD[i] = loadImage(imgLoc + "D_"+nf(i,2)+".svg");
	    imgsE[i] = loadImage(imgLoc + "E_"+nf(i,2)+".svg");
	    imgsF[i] = loadImage(imgLoc + "F_"+nf(i,2)+".svg");
	    imgsG[i] = loadImage(imgLoc + "J_"+nf(i,2)+".svg");
	    imgsH[i] = loadImage(imgLoc + "K_"+nf(i,2)+".svg");	    
    }
    //print("imgs loaded");
}
function setup() {
  // use full screen size 
  //createCanvas(displayWidth, displayHeight);
  createCanvas(600,600);
  smooth();
  colorMode(HSB,360,100,100,100);
  cursor(CROSS);
  font = textFont("sans-serif");
  fontSize = 8;
  textFont(font,fontSize);
  textAlign(CENTER,CENTER);
  gridResolutionX = round(width/tileSize)+2;
  gridResolutionY = round(height/tileSize)+2;
  activeTileColor = color(0);
  initTiles();
}

function draw() {
  //smooth();
  colorMode(HSB,360,100,100,100);
  textFont(font,8);
  textAlign(CENTER,CENTER);
  //background(360);
  background(255);
  
  if (mouseIsPressed && (mouseButton == LEFT)) setTile();
  if (mouseIsPressed && (mouseButton == RIGHT)) unsetTile();

  if (drawGrid) drawGridLines();
  drawModuls();
}

function initTiles() {
  {for (var gridX=0; gridX< gridResolutionX; gridX++) {
  	  tiles[gridX] = [];
  	  tileColors[gridX] = [];
      for (var gridY=0; gridY< gridResolutionY; gridY++)  
	      tiles[gridX][gridY] = '0';
	      tileColors[gridX][gridY] = color(random(360),random(100),random(100),100);
	      //tileColors[gridX][gridY] = color(0);
    }
  }
  //print("finish init");
}

function setTile() {
  // convert mouse position to grid coordinates
  var gridX = floor(mouseX/tileSize) + 1;
  gridX = constrain(gridX, 1, gridResolutionX-2);
  var gridY = floor(mouseY/tileSize) + 1;
  gridY = constrain(gridY, 1, gridResolutionY-2);
  tiles[gridX][gridY] = activeImgSet;
  tileColors[gridX][gridY] = activeTileColor;
  //print("finished set");
}

function unsetTile() {
  var gridX = floor(mouseX/tileSize) + 1;
  gridX = constrain(gridX, 1, gridResolutionX-2);
  var gridY = floor(mouseY/tileSize) + 1;
  gridY = constrain(gridY, 1, gridResolutionY-2);
  tiles[gridX][gridY] = '0';
  //print("finished unset");
}

function drawGridLines() {
  rectMode(CENTER);
  for (var gridY=0; gridY< gridResolutionY; gridY++) {
    for (var gridX=0; gridX< gridResolutionX; gridX++) {  
	     var posX = tileSize*gridX - tileSize/2;
	     var posY = tileSize*gridY - tileSize/2;
	     strokeWeight(0.15);
	     fill(360);
	     stroke(0);
	     noFill();
	     rect(posX, posY, tileSize, tileSize);
    }
  }
}

function drawModuls() {
  if(randomMode) activeImgSet = imgs[int(random(lngth))];
  imageMode(CENTER);
  //print("start draw");
  for (var gridY=1; gridY< gridResolutionY-1; gridY++) {  
    for (var gridX=1; gridX< gridResolutionX-1; gridX++) { 
	      //print("inside draw");
	      // use only active tiles
	      currentTile = tiles[gridX][gridY];
	      //print("current tile=" + currentTile);
	      if (currentTile != '0'){
		      //print("checking if draw");	  
		        // check the four neighbours, each can be 0 or 1
		      if(tiles[gridX+1][gridY] != '0'){
		      	var decEast = 1;
		  	  }else{
		  	  	var decEast = 0;
		      }
		      if(tiles[gridX][gridY+1] != '0'){
		      	var decSouth = 2;
		      }else{
		  	  	var decSouth = 0;
		      }
		      if(tiles[gridX-1][gridY] != '0'){
		      	var decWest = 4;
		      }else{
		  	  	var decWest = 0;
		      }
		      if(tiles[gridX][gridY+1] != '0'){
		      	var decNorth = 8;
		      }else{
		  	  	var decNorth = 0;
		      }

        var decimalResult = decNorth  + decWest + decSouth + decEast;
        var posX = tileSize*gridX - tileSize/2;
        var posY = tileSize*gridY - tileSize/2;
        //print("tile=" + tiles[gridX+1][gridY]);
        //print("gx=" + gridX + " gx-=" + (gridX-1) + " gx+=" + (gridX+1));
        //print("gy=" + gridY + " gy-=" + (gridY-1) + " gy+=" + (gridY+1));
        //print("d=" + decimalResult + " n=" + decNorth + " w=" + decWest + " s=" + decSouth + " e=" + decEast);
        //print("d=" + decimalResult + " pX=" + posX + " pY=" + posY);
        fill(tileColors[gridX][gridY]);
        noStroke();
        /*
        if ((activeImgSet) == 'A') image(imgsA[decimalResult],posX, posY, tileSize, tileSize);
        if ((activeImgSet) == 'B') image(imgsB[decimalResult],posX, posY, tileSize, tileSize);
        if ((activeImgSet) == 'C') image(imgsC[decimalResult],posX, posY, tileSize, tileSize);
        if ((activeImgSet) == 'D') image(imgsD[decimalResult],posX, posY, tileSize, tileSize);
        if ((activeImgSet) == 'E') image(imgsE[decimalResult],posX, posY, tileSize, tileSize);
        if ((activeImgSet) == 'F') image(imgsF[decimalResult],posX, posY, tileSize, tileSize);
        if ((activeImgSet) == 'J') image(imgsJ[decimalResult],posX, posY, tileSize, tileSize);
        if ((activeImgSet) == 'K') image(imgsK[decimalResult],posX, posY, tileSize, tileSize);
        */
        if ((currentTile) == 'A') image(imgsA[decimalResult],posX, posY, tileSize, tileSize);
        if ((currentTile) == 'B') image(imgsB[decimalResult],posX, posY, tileSize, tileSize);
        if ((currentTile) == 'C') image(imgsC[decimalResult],posX, posY, tileSize, tileSize);
        if ((currentTile) == 'D') image(imgsD[decimalResult],posX, posY, tileSize, tileSize);
        if ((currentTile) == 'E') image(imgsE[decimalResult],posX, posY, tileSize, tileSize);
        if ((currentTile) == 'F') image(imgsF[decimalResult],posX, posY, tileSize, tileSize);
        if ((currentTile) == 'G') image(imgsG[decimalResult],posX, posY, tileSize, tileSize);
        if ((currentTile) == 'H') image(imgsH[decimalResult],posX, posY, tileSize, tileSize);
    }
  }
}
}

function keyPressed() {
  if (key == 'b' || key == 'B') initTiles();
  if (key == 'g' || key == 'G') drawGrid = !drawGrid;
  if (key == 'r' || key == 'R') randomMode = !randomMode;
  if (key == 1) activeImgSet = 'A';
  if (key == 2) activeImgSet = 'B';
  if (key == 3) activeImgSet = 'C';
  if (key == 4) activeImgSet = 'D';
  if (key == 5) activeImgSet = 'E';
  if (key == 6) activeImgSet = 'F';
  if (key == 7) activeImgSet = 'G';
  if (key == 8) activeImgSet = 'H';
  if (key == 'a' || key == 'A') activeTileColor = color(0);
  if (key == 'c' || key == 'C') activeTileColor = color(52, 100, 71, 100);
  if (key == 'd' || key == 'D') activeTileColor = color(192, 100, 64, 100);
  if (key == 'e' || key == 'E') activeTileColor = color(273, 73, 51, 100);
  if (key == 'f' || key == 'F') activeTileColor = color(323, 100, 77,100);
}
