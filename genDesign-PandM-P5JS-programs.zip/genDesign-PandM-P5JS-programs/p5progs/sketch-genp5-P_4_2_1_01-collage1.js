// P_4_2_1_01.pde
// 
// Generative Gestaltung, ISBN: 978-3-87439-759-9
// First Edition, Hermann Schmidt, Mainz, 2009
// Hartmut Bohnacker, Benedikt Gross, Julia Laub, Claudius Lazzeroni
// Copyright 2009 Hartmut Bohnacker, Benedikt Gross, Julia Laub, Claudius Lazzeroni
//
// http://www.generative-gestaltung.de
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

/*
 * collage generator. example footage can be found in "_4_2_1_footage".
 * if you use your own footage, make sure to rename the files or adjust the prefixes: 
 * see the parameters of collageItems()
 * 
 * KEYS
 * 1-3                  : create a new collage (layer specific)
 * s                    : save png
*/

var images = [];
var imageNames = [];
var imageCnts = [];
var imagePath;
var imagesTotCnt = 0;

var layer1Items = [];
var layer2Items = [];
var layer3Items = [];
var layerCount = 3;

var items = [];

function preload() {
  // hard coded imagePath, imageCnts & imageName "prefix", and extension
  imagePath = "img-collage/";
  imageCnts[0] = 11;
  imageCnts[1] = 5;
  imageCnts[2] = 22;
  for (var i = 0; i < layerCount; i++) {
	  for (var j = 0; j < imageCnts[i] ; j++) {
	  	  imageNames[imagesTotCnt] = "layer" + nf(i + 1, 1) + "_" + nf(j + 1, 2);
	  	  images[imagesTotCnt] = loadImage(imagePath + imageNames[imagesTotCnt] + ".png");
	  	  imagesTotCnt++;
	  }
  }
}

function setup() {
  createCanvas(1024, 768);
  imageMode(CENTER);
  background(255);

  layer1Items = new collageItems("layer1", 100, width/2,height/2, width,height, 0.1,0.5, 0,0);
  layer2Items = new collageItems("layer2", 150, width/2,height/2, width,height, 0.1,0.3, -PI/2,PI/2);
  layer3Items = new collageItems("layer3", 110, width/2,height/2, width,height, 0.1,0.85, 0,0);

  // draw collage
  drawCollageItems(layer1Items);
  drawCollageItems(layer2Items);
  drawCollageItems(layer3Items); 

}

function draw() {
  // keep the programm running
}
// ------interactions and generation of the collage ------
function keyReleased() {
  if (key == 's' || key == 'S') save("P_4_3_1_02.png");

  if (key == '1') layer1Items = new collageItems("layer1", int(random(50,200)), width/2,height/2,width,height, 0.1,0.5, 0,0);
  if (key == '2') layer2Items = new collageItems("layer2", int(random(25,300)), 200,height*0.75,width,150, 0.1,random(0.3,0.8), -PI/2,PI/2);
  if (key == '3') layer3Items = new collageItems("layer3", int(random(50,300)), width/2,height*0.66,width,height*0.66, 0.1,random(0.4,0.8), -0.05,0.05);

  // draw collage
  background(255);
  drawCollageItems(layer1Items);
  drawCollageItems(layer2Items);
  drawCollageItems(layer3Items);
}

// ------ collage object ------
function collageItem(tempX, tempY, tempScale, tempRotate, tempIndex) {
  this.x = tempX
  this.y = tempY;
  this.scaling = tempScale;
  this.rotation = tempRotate;
  this.indexToImage = tempIndex;
}

// ------ collage items helper functions ------
function collageItems(thePrefix, theCount, thePosX, thePosY, theRangeX, theRangeY, theScaleStart, theScaleEnd, therotationStart, therotationEnd) {
  // collect all images with the specified prefix "thePrefix"
  var indexes = [];
  for (var i = 0 ; i < imageNames.length; i++) {
  	  var iFind = match(imageNames[i], thePrefix); // find images associated with a given layer
  	  if (iFind != null){
		indexes = append(indexes, i);
  	  }	
  }
  for (var i = 0 ; i < theCount; i++) {
    tmpX = thePosX + random(-theRangeX/2,theRangeX/2);
    tmpY = thePosY + random(-theRangeY/2,theRangeY/2);
    tmpScale = random(theScaleStart,theScaleEnd);
    tmpRotate = random(therotationStart,therotationEnd);
    tmpIndx = indexes[i % indexes.length] // cycles around the images in a given layer
    items[i] = new collageItem(tmpX, tmpY, tmpScale, tmpRotate, tmpIndx);
  }
  return items;
}

function drawCollageItems(theItems) {
  for (var i = 0 ; i < theItems.length; i++) {
    push(); + " " + theItems[i].y
	    translate(theItems[i].x, theItems[i].y);
	    rotate(theItems[i].rotation);
	    scale(theItems[i].scaling);
	    image(images[theItems[i].indexToImage], 0,0);
    pop();
  }
}