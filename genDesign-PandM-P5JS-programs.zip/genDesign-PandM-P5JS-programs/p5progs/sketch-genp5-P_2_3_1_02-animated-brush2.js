// P_2_3_1_02.pde
// 
// Generative Gestaltung, ISBN: 978-3-87439-759-9
// First Edition, Hermann Schmidt, Mainz, 2009
// Hartmut Bohnacker, Benedikt Gross, Julia Laub, Claudius Lazzeroni
// Copyright 2009 Hartmut Bohnacker, Benedikt Gross, Julia Laub, Claudius Lazzeroni
//
// http://www.generative-gestaltung.de
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

/**
 * draw tool. draw with a rotating element (svg file). 
 * 
 * MOUSE
 * drag                : draw
 * 
 * KEYS
 * 1-4                 : switch default colors
 * 5-9                 : switch brush element
 * del, backspace      : clear screen
 * d                   : reverse direction and mirrow angle 
 * space               : new random color
 * arrow left          : rotaion speed -
 * arrow right         : rotaion speed +
 * arrow up            : module size +
 * arrow down          : module size -
 * shift               : limit drawing direction
 * s                   : save png
 * r                   : start pdf recording
 * e                   : stop pdf recording


import processing.pdf.*;
import java.util.Calendar;

boolean recordPDF = false;
 */
var col;
var  imgSize = 0;
var  angle = 0;
var  angleSpeed = 1.0;
var clickPosX = 0;
var clickPosY = 0;
var img;
var img1;
var img2;
var img3;
var img4;
var img5;

function preload() {
img1 = loadImage("01-1.svg");
img2 = loadImage("02-1.svg");
img3 = loadImage("03-1.svg");
img4 = loadImage("04-1.svg")
img5 = loadImage("05-1.svg")
}

function setup() {
  // use full screen size 
  createCanvas(displayWidth, displayHeight);
  background(255);
  smooth();
  cursor(CROSS);
  col = color(181,157,0,100);
}

function draw() {
  stroke(col);
  fill(col);
  rect(5,5,10,10);
  
  
  
  if (mouseIsPressed) {
    var x = mouseX;
    var y = mouseY;
    if (keyPressed && keyCode == SHIFT) {
      if (abs(clickPosX-x) > abs(clickPosY-y)) y = clickPosY; 
      else x = clickPosX;
    }
    strokeWeight(0.75); 
    noFill();
    stroke(col);
    //print("c2 " + col);
    push();
	    translate(x, y);
	    rotate(radians(angle));
	    if (img != null) {
	      image(img, 0, 0, imgSize, imgSize);
	    } 
	    else {
	      line(0, 0, imgSize, imgSize);
	    }
	    angle = angle + angleSpeed;
	pop();
  }
}


function mouseIsPressed() {
  // create a new random color and line length
  // remember click position
  imgSize = random(50,160);
  clickPosX = mouseX;
  clickPosY = mouseY;
}

function keyPressed() {

  if (key == 'd' || key == 'D') {
    angle = angle + 180;
    angleSpeed = angleSpeed * -1;
  }

  if (key == 'n' || key == 'N') img = null;
  if (key == 1) img = img1;
  if (key == 2) img = img2;
  if (key == 3) img = img3;
  if (key == 4) img = img4;
  if (key == 5) img = img5;
  
  if (key == 'r') col = color(random(255),random(255),random(255),random(80,150));
  if (key == 6) col = color(181,157,0,100);
  if (key == 7) col = color(0,130,164,100);
  if (key == 8) col = color(87,35,129,100);
  if (key == 9) col = color(197,0,123,100);

  if (key == 'b' || key == 'B') background(255);  
  if (key == 0) stopVal = true;
  print(key);
  
  if (keyCode == UP_ARROW) imgSize += 5;
  if (keyCode == DOWN_ARROW) imgSize -= 5; 
  if (keyCode == LEFT_ARROW) angleSpeed -= 0.5;
  if (keyCode == RIGHT_ARROW) angleSpeed += 0.5; 
}
