// P_3_1_3_04.pde
// 
// Generative Gestaltung, ISBN: 978-3-87439-759-9
// First Edition, Hermann Schmidt, Mainz, 2009
// Hartmut Bohnacker, Benedikt Gross, Julia Laub, Claudius Lazzeroni
// Copyright 2009 Hartmut Bohnacker, Benedikt Gross, Julia Laub, Claudius Lazzeroni
//
// http://www.generative-gestaltung.de
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

/**
 * analysing and sorting the letters of a text 
 * connecting subsequent letters with lines
 *
 * MOUSE
 * position x          : interpolate between normal text and sorted position
 *
 * KEYS
 * 1                   : toggle grey lines on/off
 * 2                   : toggle colored lines on/off
 * 3                   : toggle text on/off
 * 4                   : switch all letters off
 * 5                   : switch all letters on
 * a-z                 : switch letter on/off
 * ctrl                : save png + pdf

import processing.pdf.*;
import java.util.Calendar;
boolean savePDF = false;
*/

var font;
var lines;
var joinedText;

var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZÄÖÜß,.;:!? ";
var counters = [];
var drawLetters = [];

var  charSize;
var charColor = 0;
var posX = 20;
var posY = 50;

var drawGreyLines = false;
var drawColoredLines = true;
var drawText = true;

function preload(){
  lines = loadStrings("img-text1/faustkurz.txt");
}

function setup() {
  createCanvas(1200, 800);
  joinedText = join(lines, " ");
  font = "Courier"
  fontSize = 10;

  for (var i = 0; i < alphabet.length; i++) {
    drawLetters[i] = true;
  }

  for(i=0;i<alphabet.length;i++){
    counters[i] = 0;
  }
  countCharacters();
}

function draw() {

  colorMode(HSB, 360, 100, 100, 100);
  textFont(font);
  background(360);
  noStroke();
  fill(0);
  smooth();

  translate(50, 0);

  posX = 0;
  posY = 200;
  var sortPositionsX = [];
  var oldPositionsX = [];
  var oldPositionsY = [];
  var oldX = 0;
  var oldY = 0;
  
  for(i = 0; i < alphabet.length; i++){
	  sortPositionsX[i] = 0.0;
	  oldPositionsX[i] = 0.0;
	  oldPositionsY[i] = 0.0;
  }
  // draw counters
  //if (mouseX >= width-50) {
  if (mouseX >= 20) {
    textSize(10);
    for (var i = 0; i < alphabet.length; i++) {
      textAlign(LEFT);
      text(alphabet.charAt(i), -15, i*20+40);
      textAlign(RIGHT);
      text(counters[i], -20, i*20+40);
    }
  }


  // go through all characters in the text to draw them
  textAlign(LEFT);
  textSize(18);
  
  for (var i = 0; i < joinedText.length; i++) {
    // again, find the index of the current letter in the alphabet
    var  s = str(joinedText.charAt(i)).toUpperCase();
    var uppercaseChar = s.charAt(0);
    var index = alphabet.indexOf(uppercaseChar);
    if (index < 0) continue;
    
    var  m = map(mouseX, 50,width-50, 0,1);
    m = constrain(m, 0, 1);

    var  sortX = sortPositionsX[index];
    print("sortX=" + index + " " + sortX);
    var  interX = lerp(posX, sortX, m);

    var  sortY = index*20+40;
    var  interY = lerp(posY, sortY, m);

    if (drawLetters[index]) {
      if (drawGreyLines) {
      	print("grey");
        if (oldX!=0 && oldY!=0) {
          stroke(0, 10);
          line(oldX,oldY, interX,interY);
        }
        oldX = interX;
        oldY = interY;
      }

      if (drawColoredLines) {
      	print("color" + " " + oldPositionsX[index]  + " " + oldPositionsY[index] );
        if (oldPositionsX[index]!=0 && oldPositionsY[index]!=0) {
          stroke(index*10, 80, 60, 50);
          line(oldPositionsX[index],oldPositionsY[index], interX,interY);
        }
        oldPositionsX[index] = interX;
        oldPositionsY[index] = interY;
      }

      if (drawText) {
      	print("text");
        text(joinedText.charAt(i), interX, interY);
      }
    }
    else {
      oldX = 0;
      oldY = 0;
    }

    sortPositionsX[index] += textWidth(joinedText.charAt(i));
    posX += textWidth(joinedText.charAt(i));
    if (posX >= width-200 && uppercaseChar == ' ') {
      posY += 40;
      posX = 0;
    }
  }
}

function countCharacters() {
  for (var i = 0; i < joinedText.length; i++) {
    // get one char from the text, convert it to a string and turn it to uppercase
    var  s = str(joinedText.charAt(i)).toUpperCase();
    // convert it back to a char
    var uppercaseChar = s.charAt(0);
    // get the position of this char inside the alphabet string
    var index = alphabet.indexOf(uppercaseChar);
    // increase the respective counter
    if (index >= 0){
       counters[index] += 1;
    }
  }
}

function keyPressed(){
  if (key == '1') drawGreyLines = !drawGreyLines;
  if (key == '2') drawColoredLines = !drawColoredLines;
  if (key == '3') drawText = !drawText;
  if (key == '4') {
    for (var i = 0; i < alphabet.length; i++) {
      drawLetters[i] = false;
    }
  }
  if (key == '5') {
    for (var i = 0; i < alphabet.length; i++) {
      drawLetters[i] = true;
    }
  }
  var  s = str(key).toUpperCase();
  var uppercaseKey = s.charAt(0);
  var index = alphabet.indexOf(uppercaseKey);
  if (index >= 0) {
    drawLetters[index] = !drawLetters[index];
  }
}
