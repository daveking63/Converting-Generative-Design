// P_1_2_3_03.pde
// 
// Generative Gestaltung, ISBN: 978-3-87439-759-9
// First Edition, Hermann Schmidt, Mainz, 2009
// Hartmut Bohnacker, Benedikt Gross, Julia Laub, Claudius Lazzeroni
// Copyright 2009 Hartmut Bohnacker, Benedikt Gross, Julia Laub, Claudius Lazzeroni
//
// http://www.generative-gestaltung.de
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

/**
 * generates a specific color palette and some random "rect-tilings"
 * 
 * MOUSE
 * left click          : new composition
 * 
 * KEYS
 * s                   : save png
 * c                   : save color palette


import generativedesign.*;
import processing.opengl.*;
import java.util.Calendar;
 */
var colorCount = 20;
var hueValues = [];
var saturationValues = [];
var brightnessValues = [];
//var alphaValue = 27;
var alphaValue = 150;
var actRandomSeed = 0;

function setup() {
  //createCanvas(800,800,WEBGL);
  createCanvas(800,800); 
  colorMode(HSB,360,100,100,255);
  noStroke();
}

function draw() { 
  background(0,0,0);
  randomSeed(actRandomSeed);

  // ------ colors ------
  // create palette
  for (var i=0; i<colorCount; i++) {
    if (i%2 == 0) {
      hueValues[i] = floor(random(0,360));
      saturationValues[i] = 100;
      brightnessValues[i] = floor(random(0,100));
    } 
    else {
      hueValues[i] = 195;
      saturationValues[i] = floor(random(0,100));
      brightnessValues[i] = 100;
    }
  }

  // ------ area tiling ------
  var counter = 0;
  var rowCount = floor(random(5,30));
  var rowHeight = height/rowCount;
  //print("rC-rH" + rowCount + " " + rowHeight);

  // seperate each line in parts  
  for(var i=rowCount; i>=0; i--) {
    var partCount = i+1;
    var parts = [];
    //print ("pC" +  partCount);
    
    for(var ii=0; ii<partCount; ii++) {
      // sub fragments or not?
      if (random(1.0) < 0.075) {
        // take care of big values     
        var fragments = floor(random(2,20));
        partCount = partCount + fragments; 
        for(var iii=0; iii<fragments; iii++) {
          parts = append(parts, random(2));
        }              
      } else {
        parts = append(parts, random(2,20));   
      }
    }
//  }
    // add all subparts
    var sumPartsTotal = 0;
	for(var ii=0; ii<partCount; ii++) sumPartsTotal += parts[ii];

    // draw rects
    var sumPartsNow = 0;
    for(var ii=0; ii<partCount; ii++) {
      sumPartsNow += parts[ii];

      var x = map(sumPartsNow, 0,sumPartsTotal, 0,width);
      var y = rowHeight*i;
      var w = map(parts[ii], 0,sumPartsTotal, 0,width)*-1;
      var h = rowHeight*1.5;

      beginShape();
	      //print("shp" + ii);  
	      fill(0,0,0,180);
	      vertex(x,y);
	      vertex(x+w,y);
	      // get component color values + aplha
	      var index = counter % colorCount;
	      fill(hueValues[index],saturationValues[index],brightnessValues[index],alphaValue);
	      vertex(x+w,y+h);
	      vertex(x,y+h);
      endShape(CLOSE);

      counter++;
    
  }  
} 
}
function mouseReleased() {
  actRandomSeed = floor(random(100000));
}
