// M_2_5_01.pde
// 
// Generative Gestaltung, ISBN: 978-3-87439-759-9
// First Edition, Hermann Schmidt, Mainz, 2009
// Hartmut Bohnacker, Benedikt Gross, Julia Laub, Claudius Lazzeroni
// Copyright 2009 Hartmut Bohnacker, Benedikt Gross, Julia Laub, Claudius Lazzeroni
//
// http://www.generative-gestaltung.de
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

/**
 * draw lissajous figures with all points connected
 *
 * KEYS
 * 1/2               : frequency x -/+ 
 * 3/4               : frequency y -/+ 
 * arrow left/right  : phi -/+
 * 7/8               : modulation frequency x -/+
 * 9/0               : modulation frequency y -/+
 * s                 : save png
 * p                 : save pdf



// ------ imports ------

import processing.pdf.*;
import java.util.Calendar;
 */

// ------ initial parameters and declarations ------

var pointCount = 1000;
var lissajousPoints = [];
//PVector[] lissajousPoints = new PVector[0];

var freqX = 4;
var freqY = 7;
var phi = 15;

var modFreqX = 3;
var modFreqY = 2;

var lineWeight = 1;
var lineColor;
//color lineColor = color(0, 130, 164);
var lineAlpha = 50;

var connectionRadius = 100;
var connectionRamp = 6;

function setup() {
  createCanvas(800, 800);
  smooth();
  lineColor = color(255,50,0,50);
  calculateLissajousPoints();
  drawLissajous();
}

function draw() {
}


function calculateLissajousPoints() {
  //lissajousPoints = new PVector[pointCount+1];

  for (var i=0; i<=pointCount; i++) {
    var angle = map(i, 0,pointCount, 0,TWO_PI);
    var x = sin(angle * freqX + radians(phi)) * cos(angle * modFreqX);
    var y = sin(angle * freqY) * cos(angle * modFreqY);

    x = x * (width/2-30);
    y = y * (height/2-30);

    //lissajousPoints[i] = new PVector(x, y);
    lissajousPoints[i] = createVector(x, y);
  }
}


function drawLissajous() {
  var d, a, h;

  colorMode(RGB, 255, 255, 255, 100);
  background(255);
  strokeWeight(lineWeight);
  strokeCap(ROUND);
  noFill();

  push();
  translate(width/2, height/2);

  for (var i1 = 0; i1 < pointCount; i1++) {
    for (var i2 = 0; i2 < i1; i2++) {
      //PVector p1 = lissajousPoints[i1];
      //PVector p2 = lissajousPoints[i2];
      p1 = lissajousPoints[i1];
      p2 = lissajousPoints[i2];

      //d = PVector.dist(p1, p2);
      d = p1.dist(p2);
      a = pow(1/(d/connectionRadius+1), 6);

      if (d <= connectionRadius) {
        stroke(lineColor,  a*lineAlpha);
        line(p1.x, p1.y, p2.x, p2.y);
      }
    }
  }
  pop();
}

function keyPressed(){

  if(key == '1') freqX--;
  if(key == '2') freqX++;
  freqX = max(freqX, 1);

  if(key == '3') freqY--;
  if(key == '4') freqY++;
  freqY = max(freqY, 1);

  if(key == '7') modFreqX--;
  if(key == '8') modFreqX++;
  modFreqX = max(modFreqX, 1);
  
  if(key == '9') modFreqY--;
  if(key == '0') modFreqY++;
  modFreqY = max(modFreqY, 1);
  
  if (keyCode == LEFT_ARROW) phi -= 15;
  if (keyCode == RIGHT_ARROW) phi += 15;
  
  calculateLissajousPoints();
  drawLissajous();

  //println("freqX: " + freqX + ", freqY: " + freqY + ", phi: " + phi + ", modFreqX: " + modFreqX + ", modFreqY: " + modFreqY); 
}

