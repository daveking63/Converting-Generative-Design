// P_2_3_4_01.pde
// 
// Generative Gestaltung, ISBN: 978-3-87439-759-9
// First Edition, Hermann Schmidt, Mainz, 2009
// Hartmut Bohnacker, Benedikt Gross, Julia Laub, Claudius Lazzeroni
// Copyright 2009 Hartmut Bohnacker, Benedikt Gross, Julia Laub, Claudius Lazzeroni
//
// http://www.generative-gestaltung.de
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

/**
 * draw tool. shows how to draw with dynamic elements. 
 * 
 * MOUSE
 * drag                : draw
 * 
 * KEYS
 * 1-9                 : switch module
 * del, backspace      : clear screen
 * arrow up            : module size +
 * arrow down          : module size -
 * arrow left          : step size -
 * arrow right         : step size +
 * s                   : save png
 * r                   : start pdf recording
 * e                   : stop pdf recording


import processing.pdf.*;
import java.util.Calendar;

boolean recordPDF = false;
*/
var  x = 0, y = 0;
var  stepSize = 5.0;
var  imgSize = 25;
var img;
var img1;
var img2;
var img3;
var img4;
var img5;
var img6;
var img7;
var img8;
var img9;

function preload() {
img1 = loadImage("imgs-brush4/01-2.svg");
img2 = loadImage("imgs-brush4/02-2.svg");
img3 = loadImage("imgs-brush4/03-2.svg");
img4 = loadImage("imgs-brush4/04-2.svg")
img5 = loadImage("imgs-brush4/05-2.svg")
img6 = loadImage("imgs-brush4/06-2.svg")	
img7 = loadImage("imgs-brush4/07-2.svg")	
img8 = loadImage("imgs-brush4/08-2.svg")	
img9 = loadImage("imgs-brush4/09-2.svg")	
}

function setup() {
  // use full screen createCanvas 
  createCanvas(displayWidth, displayHeight);
  background(255);
  smooth();
  x = mouseX;
  y = mouseY;
  cursor(CROSS);
  img = img1;
}

function draw() {
  if (mouseIsPressed) {
    var  d = dist(x,y, mouseX,mouseY);

    if (d > stepSize) {
      var  angle = atan2(mouseY-y, mouseX-x); 
      push();
	      translate(mouseX, mouseY);
	      rotate(angle+PI);
	      //shape(lineModule, 0, 0, d, imgSize);
	      image(img, 0, 0, d, imgSize);
      pop();
      x = x + cos(angle) * stepSize;
      y = y + sin(angle) * stepSize;
    }
  }
}

function mousePressed() {
  x = mouseX;
  y = mouseY;
}

function keyPressed() {
	  if (key == DELETE || key == BACKSPACE) background(255);
	  // load svg for line module
	  if (key == 1) img = img1;
	  if (key == 2) img = img2;
	  if (key == 3) img = img3;
	  if (key == 4) img = img4;
	  if (key == 5) img = img5;
	  if (key == 6) img = img6;
	  if (key == 7) img = img7;
	  if (key == 8) img = img8;
	  if (key == 9) img = img9;
	  if (key == 'b' || key == 'B') background(255);  
      if (key == 0) stopVal = true;
	  // imgSize ctrls arrowkeys up/down 
	  if (keyCode == UP_ARROW) imgSize += 5;
	  if (keyCode == DOWN_ARROW) imgSize -= 5; 
	  // stepSize ctrls arrowkeys left/right
	  stepSize = max(stepSize,0.5);   
	  if (keyCode == LEFT_ARROW) stepSize -= 0.5;
	  if (keyCode == RIGHT_ARROW) stepSize += 0.5; 
	  //print("imgSize: "+imgSize+"  stepSize: "+stepSize);
}
