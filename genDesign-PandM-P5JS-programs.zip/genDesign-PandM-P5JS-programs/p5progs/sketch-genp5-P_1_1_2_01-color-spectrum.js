// P_1_1_2_01.pde

var segmentCount = 360;
var radius = 300;
var vx;
var vy;
var angleStep;

function setup(){
  createCanvas(800, 800);
}

function draw(){
  noStroke();
  colorMode(HSB, 360, width, height);
  background(360);
  
  if (keyIsPressed) {
	if (key == 1) {
		segmentCount = 360;
	}
	if (key == 2) {
		segmentCount = 180;
	}
	if (key == 3) {
		segmentCount = 90;
	}
	if (key == 4) {
		segmentCount = 45;
	}
	if (key == 5) {
		segmentCount = 24;
	}	
	if (key == 6) {
		segmentCount = 12;
	}
	if (key == 7) {
		segmentCount = 6;
    }
  }
  angleStep = 360/segmentCount;

  beginShape(TRIANGLE_FAN);
  vertex(width/2, height/2);
  for (var angle=0; angle<=360; angle+=angleStep){
    vx = width/2 + cos(radians(angle))*radius;
    vy = height/2 + sin(radians(angle))*radius;
    vertex(vx, vy);
    fill(angle, mouseX, mouseY);
  }
  endShape();
}
