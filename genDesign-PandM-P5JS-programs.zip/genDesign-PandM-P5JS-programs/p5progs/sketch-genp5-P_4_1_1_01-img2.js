// P_4_1_1_01.pde
// 
// Generative Gestaltung, ISBN: 978-3-87439-759-9
// First Edition, Hermann Schmidt, Mainz, 2009
// Hartmut Bohnacker, Benedikt Gross, Julia Laub, Claudius Lazzeroni
// Copyright 2009 Hartmut Bohnacker, Benedikt Gross, Julia Laub, Claudius Lazzeroni
//
// http://www.generative-gestaltung.de
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

/**
 * cutting and multiplying an area of the image
 * 
 * MOUSE
 * position x/y         : area position
 * left click           : multiply the area
 * 
 * KEYS
 * 1-3                  : area size
 * r                    : toggle random area
 * s                    : save png

import java.util.Calendar;
 */
var img;
var tileCountX = 4;
var tileCountY = 4;
var tileCount = tileCountX*tileCountY;
var imageTiles = [];
var tileWidth, tileHeight;
var cropX = 0;
var cropY = 0;
var selectMode = true;
var randomMode = false; 

function preload(){
  img = loadImage("img-img2/image2.jpg");
}	

function setup() {
  createCanvas(1600, 1200); 
  image(img, 0, 0);
  noCursor();
  tileWidth = width/tileCountY;
  tileHeight = height/tileCountX;
}

function draw() {
  if (selectMode == true) {
    // in selection mode, a white selection rectangle is drawn over the image
    cropX = constrain(mouseX, 0, width-tileWidth);
    cropY = constrain(mouseY, 0, height-tileHeight);    
    image(img, 0, 0);
    noFill();
    stroke(255);
    rect(cropX, cropY, tileWidth, tileHeight);
  } 
  else {
    // reassemble image
    var i = 0;
    for (var gridY = 0; gridY < tileCountY; gridY++){
      for (var gridX = 0; gridX < tileCountX; gridX++){
        image(imageTiles[i], gridX*tileWidth, gridY*tileHeight);
        i++;
      }
    }
  }
}

function cropTiles() {
  tileWidth = width/tileCountY;
  tileHeight = height/tileCountX;
  tileCount = tileCountX * tileCountY;
  //imageTiles = [];

  var i = 0;
  for (var gridY = 0; gridY < tileCountY; gridY++){
    for (var gridX = 0; gridX < tileCountX; gridX++){
      if (randomMode){
        cropX = floor(random(mouseX-tileWidth/2, mouseX+tileWidth/2));
        cropY = floor(random(mouseY-tileHeight/2, mouseY+tileHeight/2));
      }
      cropX = constrain(cropX, 0, width-tileWidth);
      cropY = constrain(cropY, 0, height-tileHeight);
      imageTiles[i++] = img.get(cropX, cropY, tileWidth, tileHeight);
    }
  }
}


function mousePressed() {
  selectMode = true;
}

function mouseReleased(){
  selectMode = false;
  cropTiles();
}

function keyReleased(){
  if (key == 'r' || key == 'R') {
    randomMode = !randomMode;
    cropTiles();
  }

  if (key == '1'){
    tileCountY = 4;
    tileCountX = 4;
    cropTiles();
  }
  if (key == '2'){
    tileCountY = 10;
    tileCountX = 10;
    cropTiles();
  }
  if (key == '3'){
    tileCountY = 20;
    tileCountX = 20;
    cropTiles();
  }
}
